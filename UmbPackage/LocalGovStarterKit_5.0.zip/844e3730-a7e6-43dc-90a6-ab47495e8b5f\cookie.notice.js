﻿/* Jumoo, 2015 - a v'small we use cookies - this one uses jQuery*/
